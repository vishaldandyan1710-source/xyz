
document.addEventListener("DOMContentLoaded",()=>{
  const nav=document.querySelector(".site-nav");
  const menu=document.querySelector(".menu");
  const links=document.querySelector(".nav-links");
  const reduced=window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if(menu) menu.addEventListener("click",()=>links.classList.toggle("open"));
  document.querySelectorAll(".nav-links a").forEach(a=>a.addEventListener("click",()=>links?.classList.remove("open")));

  if(!reduced && window.gsap){
    gsap.registerPlugin(ScrollTrigger);

    const heroMedia=document.querySelector(".hero-media");
    if(heroMedia){
      gsap.to(heroMedia,{scale:1.18,ease:"none",scrollTrigger:{trigger:".hero",start:"top top",end:"bottom top",scrub:1}});
    }

    gsap.utils.toArray(".reveal").forEach(el=>{
      gsap.to(el,{opacity:1,y:0,duration:1.05,ease:"power3.out",scrollTrigger:{trigger:el,start:"top 86%",once:true}});
    });

    gsap.utils.toArray(".clip").forEach(el=>{
      gsap.to(el.children,{y:0,duration:1.1,ease:"power4.out",stagger:.08,scrollTrigger:{trigger:el,start:"top 85%",once:true}});
    });

    gsap.utils.toArray(".service-row").forEach((row,i)=>{
      gsap.from(row,{x:-35,opacity:0,duration:.7,ease:"power3.out",delay:i*.035,scrollTrigger:{trigger:row,start:"top 90%",once:true}});
    });

    gsap.utils.toArray(".masonry .image-wrap").forEach((img,i)=>{
      gsap.from(img,{y:50,opacity:0,duration:1,ease:"power3.out",delay:i*.05,scrollTrigger:{trigger:img,start:"top 90%",once:true}});
    });

    gsap.utils.toArray(".stat strong").forEach(el=>{
      const target=parseInt(el.dataset.value||el.textContent,10);
      const obj={v:0};
      gsap.to(obj,{v:target,duration:1.6,ease:"power2.out",scrollTrigger:{trigger:el,start:"top 88%",once:true},onUpdate:()=>el.textContent=Math.round(obj.v)+"+"});
    });
  }else{
    document.querySelectorAll(".reveal").forEach(el=>{el.style.opacity=1;el.style.transform="none"});
    document.querySelectorAll(".clip > *").forEach(el=>el.style.transform="none");
  }

  const updateNav=()=>{ if(nav) nav.classList.toggle("scrolled",scrollY>40) };
  updateNav(); addEventListener("scroll",updateNav,{passive:true});

  const cursor=document.querySelector(".cursor");
  if(cursor && innerWidth>800 && !reduced){
    addEventListener("mousemove",e=>{gsap.to(cursor,{x:e.clientX,y:e.clientY,duration:.15,ease:"power2.out"})});
    document.querySelectorAll("a,.btn,.image-wrap").forEach(el=>{
      el.addEventListener("mouseenter",()=>gsap.to(cursor,{scale:1.8,duration:.2}));
      el.addEventListener("mouseleave",()=>gsap.to(cursor,{scale:1,duration:.2}));
    });
  }

  const form=document.querySelector("#enquiryForm");
  if(form) form.addEventListener("submit",e=>{
    e.preventDefault();
    const data=new FormData(form);
    const msg=`Hello Amoura, I would like to enquire about an appointment.%0A%0AName: ${encodeURIComponent(data.get("name")||"")}%0APhone: ${encodeURIComponent(data.get("phone")||"")}%0AService: ${encodeURIComponent(data.get("service")||"")}%0APreferred date: ${encodeURIComponent(data.get("date")||"")}%0AMessage: ${encodeURIComponent(data.get("message")||"")}`;
    window.open("https://wa.me/919999999999?text="+msg,"_blank");
  });
});

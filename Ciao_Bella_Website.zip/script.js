
const nav=document.querySelector('.nav');
window.addEventListener('scroll',()=>{if(nav)nav.classList.toggle('scrolled',scrollY>30)});

const menu=document.querySelector('.menu');
const links=document.querySelector('.navlinks');
if(menu&&links){
 menu.addEventListener('click',()=>{links.style.display=links.style.display==='flex'?'none':'flex';links.style.position='absolute';links.style.top='70px';links.style.left='14px';links.style.right='14px';links.style.flexDirection='column';links.style.background='var(--cream)';links.style.padding='25px';links.style.boxShadow='0 20px 50px #0002'});
}

const observer=new IntersectionObserver(entries=>{
 entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('show')});
},{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

document.querySelectorAll('.filter').forEach(btn=>{
 btn.addEventListener('click',()=>{
  document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const cat=btn.dataset.filter;
  document.querySelectorAll('.masonry figure').forEach(item=>{
   item.style.display=(cat==='all'||item.dataset.category===cat)?'block':'none';
  });
 });
});

const lightbox=document.querySelector('.lightbox');
const lightImg=lightbox?.querySelector('img');
document.querySelectorAll('.masonry figure').forEach(fig=>{
 fig.addEventListener('click',()=>{
  if(!lightbox)return;
  lightImg.src=fig.querySelector('img').src;
  lightImg.alt=fig.querySelector('img').alt;
  lightbox.classList.add('open');
 });
});
document.querySelector('.close')?.addEventListener('click',()=>lightbox.classList.remove('open'));
lightbox?.addEventListener('click',e=>{if(e.target===lightbox)lightbox.classList.remove('open')});
document.addEventListener('keydown',e=>{if(e.key==='Escape')lightbox?.classList.remove('open')});

const form=document.querySelector('#enquiryForm');
if(form){
 form.addEventListener('submit',e=>{
  e.preventDefault();
  const d=new FormData(form);
  const msg=`Hello Ciao Bella, I would like to make an enquiry.%0A%0AName: ${d.get('name')}%0APhone: ${d.get('phone')}%0AEmail: ${d.get('email')}%0AService: ${d.get('service')}%0APreferred Date: ${d.get('date')}%0APreferred Time: ${d.get('time')}%0AMessage: ${d.get('message')||'N/A'}`;
  window.open(`https://wa.me/919888955800?text=${msg}`,'_blank');
 });
}
